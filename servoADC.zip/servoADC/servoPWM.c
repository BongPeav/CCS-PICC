#include<16F716.h>
#fuses HS
#use delay(clock=20M)

void main(){
   int32 adcResult_1;
   int32 adcResult_2;
   int32 adcResult_3;
   
   int32 _h_1=0,_l_1=0;
   int32 _h_2=0,_l_2=0;
   int32 _h_3=0,_l_3=0;
   
   output_B(0x00);
   set_tris_a(0xFF);
   set_tris_b(0x00);
   setup_adc(ADC_CLOCK_INTERNAL);
   setup_adc_ports(AN0_AN1_AN3);
   
   delay_ms(2000);
   
   while(1){
   //Servo 1
      set_adc_channel(0);
      adcResult_1=read_adc();
      while(!adc_done());
      
      _h_1=1000+((1000*adcResult_1)/255);
      _l_1=20000-_h_1;
          
      output_high(pin_b0);
      delay_us(_h_1);
      output_low(pin_b0);
      delay_us(_l_1);
      
      //Servo 2
      set_adc_channel(1);
      adcResult_2=read_adc();
      while(!adc_done());
      
      _h_2=1000+((1000*adcResult_2)/255);
      _l_2=20000-_h_2;
          
      output_high(pin_b1);
      delay_us(_h_2);
      output_low(pin_b1);
      delay_us(_l_2);
      
       //Servo 3
      set_adc_channel(3);
      adcResult_3=read_adc();
      while(!adc_done());
      
      _h_3=1000+((1000*adcResult_3)/255);
      _l_3=20000-_h_3;
          
      output_high(pin_b2);
      delay_us(_h_3);
      output_low(pin_b2);
      delay_us(_l_3);
   }
}

