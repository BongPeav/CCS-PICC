
#include <16F84A.h>
#fuses XT
#use delay(clock=4000000)

#define LCD_ENABLE_PIN  PIN_B3                                        
#define LCD_RS_PIN      PIN_B1                                         
#define LCD_RW_PIN      PIN_B2                                        
#define LCD_DATA4       PIN_B4                                        
#define LCD_DATA5       PIN_B5                                       
#define LCD_DATA6       PIN_B6                                       
#define LCD_DATA7       PIN_B7

#include <lcd.c>
#include <touch.c>
#include <string.h>
#include <stdlib.h>

#define RELAY PIN_A0
#define TEMP 30
void main() {
   byte buffer[2];
   lcd_init();
   set_tris_a(0x00);
   output_a(0x00);
   
   while (TRUE) {
     if(touch_present()) {
        touch_write_byte(0xCC);
        touch_write_byte (0x44);
        output_high(TOUCH_PIN);
        delay_ms(2000);

        touch_present();
        touch_write_byte(0xCC);
        touch_write_byte (0xBE);
        buffer[0] = touch_read_byte();
        buffer[1] = touch_read_byte();
        
        buffer[0]=(buffer[1]<<5)|(buffer[0]>>3);
        
        lcd_gotoxy(1,1); 
        LCD_PUTC("TEMPERATURE:");
        
        lcd_gotoxy(1,2);
        printf(LCD_PUTC,"%c",(buffer[1]&0b11111000)?'-':' ');
        if(buffer[1]&0b11111000) buffer[0]=-buffer[0];
        lcd_gotoxy(2,2);
        printf(LCD_PUTC,"%d.%c C",buffer[0]/2,((buffer[0])&0x01)?'5':'0');
        delay_ms (500);
        lcd_putc("          ");
        
        if((buffer[0]/2)>TEMP) output_high(RELAY);
        else output_low(RELAY);
     }
  }
}
