/*
Digital Input expanding Using 74HC165 SPI
*/
#include<16F84A.h>
#fuses XT
#use delay(clock=4M)

//Pre-Define Parameters For 74165.c
#define EXP_IN_ENABLE   PIN_A1
#define EXP_IN_CLOCK    PIN_A0
#define EXP_IN_DI       PIN_A2
#define NUMBER_OF_74165 1

#include<74165.c>

void main(void){
   char readInput;
   output_b(0x00);
   set_tris_b(0x00);
   
   while(1){
      read_expanded_inputs(&readInput);
      output_b(readInput);
      delay_ms(100);
   }
}
