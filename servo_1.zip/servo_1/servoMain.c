#include<16F84A.h>
#fuses HS
//for delay function
#use delay(clock=20M)

void main(){
   int16 highTime=0;
   unsigned int16 _H=0,_L=0;
   output_b(0x00);
   //make RB0.1 inputs
   set_tris_b(0x03);
   //turn on port b input pullups
   port_b_pullups(true);
   
   
   while(1){
      //increase the angle
      if(input(pin_B0)==0){
         delay_ms(5);
         if(_H<2000)
         highTime+=50;
         //making high pulse
         _H=1000+(highTime/18);
         //calculate the total 20 ms period
         _L=20000-_H;
         //start the rotation
         output_high(PIN_B2);
         delay_us(_H);
         output_low(PIN_B2);
         delay_us(_L);
      }
      //decrease the angle
      if(input(pin_B1)==0){
         delay_ms(5);
         if(_H>1000)
         highTime-=50;
         //making high pulse
         _H=1000+(highTime/18); 
         //calculate the total 20 ms period
         _L=20000-_H;      
         //start the rotation
         output_high(PIN_B2);
         delay_us(_H);
         output_low(PIN_B2);
         delay_us(_L);
      }
   }
}
